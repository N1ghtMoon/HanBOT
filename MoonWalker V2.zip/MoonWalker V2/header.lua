return {
  id = "MoonWalkerV2",
  name = "MoonWalker V2",
  riot = true,
  flag = {
    text = 'NightMoon',
    color = { 
      text = 0xffeeeeee, 
      background1 = 0x66f77474, 
      background2 = 0x99000000, 
    },
  },
  load = function()
    return true
  end,
}